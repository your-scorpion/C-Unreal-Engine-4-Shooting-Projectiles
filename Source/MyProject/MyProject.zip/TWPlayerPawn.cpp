// Fill out your copyright notice in the Description page of Project Settings.


#include "TWPlayerPawn.h"

// Sets default values
ATWPlayerPawn::ATWPlayerPawn()
{
	PrimaryActorTick.bCanEverTick = true;
	BodyMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("BodyMeshComponent");
	SetRootComponent(BodyMeshComponent);
	
	TurretMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("TurretMeshComponent");
	TurretMeshComponent -> SetupAttachment(BodyMeshComponent);

	SpringArmComponent= CreateDefaultSubobject<USpringArmComponent>("SpringArmComponent");//откуда рендер будет произведен
	SpringArmComponent -> SetupAttachment(BodyMeshComponent);

	FollowCamera= CreateDefaultSubobject<UCameraComponent>("FollowCamera");//отвечает за рендер
	FollowCamera -> SetupAttachment(SpringArmComponent);

	//USpringArmComponent* SpringArmComponent;


	//UCameraComponent* FollowCamera;

	//UStaticMeshComponent* TurretMeshComponent;

}

void ATWPlayerPawn::BeginPlay()
{
	Super::BeginPlay();
	
}

void ATWPlayerPawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	PerformMovement(DeltaTime);
	
}

void ATWPlayerPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	//PlayerInputComponent -> BindAction()
	PlayerInputComponent -> BindAxis("MoveForward", this, &ATWPlayerPawn::OnMoveForwardInput);
	PlayerInputComponent -> BindAxis("MoveRight", this, &ATWPlayerPawn::OnMoveRightInput);


}

void ATWPlayerPawn::PerformMovement(float DeltaTime)
{
	//FVector location = GetActorLocation();
	//SetActorLocation(location);

	//FRotator rotation = GetActorRotation();

	CurrentMoveSpeed = FMath::FInterpConstantTo(CurrentMoveSpeed, MoveSpeed * FMath::Abs(MoveForwardInput), DeltaTime, MoveAcceleration);
	const FVector moveDelta = GetActorForwardVector() * CurrentMoveSpeed * DeltaTime * FMath::Sign(MoveForwardInput);
	SetActorLocation(GetActorLocation() + moveDelta);

	CurrentRotationSpeed = FMath::FInterpConstantTo(CurrentRotationSpeed, RotationSpeed * FMath::Abs(MoveRightInput), DeltaTime, RotationAcceleration);
	const FRotator rotationDelta = FRotator(0.f, CurrentRotationSpeed * DeltaTime * FMath::Sign(MoveRightInput), 0.f );
	SetActorRotation(GetActorRotation() + rotationDelta);

		
}	


void ATWPlayerPawn::OnMoveForwardInput(float AxisValue)
{
	MoveForwardInput = AxisValue;
}


void ATWPlayerPawn::OnMoveRightInput(float AxisValue)
{
	MoveRightInput = AxisValue;
}
